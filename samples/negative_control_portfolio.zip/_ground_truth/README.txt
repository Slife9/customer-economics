Evaluation-only. Never join into any table the analytical engine reads.
Latents and the true default hazard are the causes.
Defects are planted Type A failures with mechanism and impact.
